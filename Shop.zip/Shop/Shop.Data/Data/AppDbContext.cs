﻿using Microsoft.EntityFrameworkCore;
using Shop.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Data.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasKey(p => p.Id);
            modelBuilder.Entity<User>()
                .Property("Name")
                .HasColumnType("nvarchar(20)");
            modelBuilder.Entity<User>()
                .Property("Email")
                .HasColumnType("nvarchar(30)");
            modelBuilder.Entity<User>()
                .Property("Password")
                .HasColumnType("nvarchar(70)");
            modelBuilder.Entity<User>()
                .Property("isAdmin")
                .HasConversion<string>()
                .HasColumnName("Admin")
                .HasColumnType("nvarchar(6)");



            modelBuilder.Entity<Product>()
                .HasKey(p => p.Id);
                
            modelBuilder.Entity<Product>()
                .Property("Name")
                .HasColumnType("nvarchar(20)");
            modelBuilder.Entity<Product>()
                .Property("Description")
                .HasColumnType("nvarchar(max)");
            modelBuilder.Entity<Product>()
                .Property("Price")
                .HasColumnType("decimal(18,2)");
            modelBuilder.Entity<Product>()
                .Property("Brend")
                .HasConversion<string>()
                .HasColumnType("nvarchar(20)");
            modelBuilder.Entity<Product>()
                .Property("productType")
                .HasColumnName("Type")
                .HasConversion<string>()
                .HasColumnType("nvarchar(20)");

            modelBuilder.Entity<Order>()
                .HasKey(o => o.Id);
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Order> Orders { get; set; }

    }
}
