﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Data.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public decimal Sum {  get; set; }

        public Dictionary<Product, int> _products = new();
        public Order() { }
        public Order(User user, decimal sum)
        {
            UserId = user.Id;
            _products=user.Cart;
            Sum = sum;
        }
    }
}
