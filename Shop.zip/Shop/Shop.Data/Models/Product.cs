﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Data.Models
{
    public class Product
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public required string Description { get; set; }
        public required decimal Price { get; set; }
        public Brend Brend { get; set; }
        public ProductType productType { get; set; }


    }
    public enum Brend
    {
        Apple,
        Samsung,
        Xiaomi,
        Huawei,
        Meizu
    }
    public enum ProductType
    {
        SmartPhone,
        SmartWatch,
        Earphone
    }
}
