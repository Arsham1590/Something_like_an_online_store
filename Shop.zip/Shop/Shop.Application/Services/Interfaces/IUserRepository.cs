﻿using Shop.Data.Models;


namespace Shop.Application.Services.Interfaces
{
    public interface IUserRepository
    {
        Task<string> GetUser(string mail, string password);
        Task Register(string name, string email, string password);
        Task AddToCart(int productId);
        Task<string> MakePurchase();
        Task Delete(string mail);
    }
}
