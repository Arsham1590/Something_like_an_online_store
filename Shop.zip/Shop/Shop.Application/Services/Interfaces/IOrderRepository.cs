﻿using Shop.Data.Models;


namespace Shop.Application.Services.Interfaces
{
    public interface IOrderRepository
    {
        Task<string> MakeOrder(User user);
    }
}
