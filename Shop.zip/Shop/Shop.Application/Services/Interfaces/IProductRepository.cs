﻿using Shop.Data.Models;


namespace Shop.Application.Services.Interfaces
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAll();
        Task<List<Product>> GetByBrend(Brend brend);
        Task<List<Product>> GetByType(ProductType type);
        Task<Product?> GetById(int id);
        Task Add(string Name, string Description, decimal Price, Brend brend, ProductType type);
        Task Update(int id, Product updatedProduct);
        Task Delete(int id);
    }
}
