﻿
namespace Shop.Application.Services
{
    public class PasswordHasher
    {
        public static string Generate(string password)
        {
            var x = BCrypt.Net.BCrypt.EnhancedHashPassword(password);
            return x;
        }
        public static bool Verify(string password, string hashPassword)
        {
            return BCrypt.Net.BCrypt.EnhancedVerify(password, hashPassword);
        }
    }
}
