﻿using Microsoft.EntityFrameworkCore;
using Shop.Application.Services.Interfaces;
using Shop.Data.Data;
using Shop.Data.Models;

namespace Shop.Application.Services.Repositories
{
    public class ProductRepository : IProductRepository
    {
        public readonly AppDbContext _context;

        public ProductRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task Add(string name, string description, decimal price, Brend brend, ProductType type)
        {
            if (!_context.Products.Select(p => p.Name).Contains(name))
            {
                await _context.Products.AddAsync(new Product() 
                {
                    Name = name,
                    Description = description,
                    Price = price,
                    Brend = brend,
                    productType = type
                }
                );
                await _context.SaveChangesAsync();
            }
        }
        public async Task Delete(int id)
        {
            var deletedProduct = await GetById(id);
            if (deletedProduct is not null)
            {
                _context.Products.Where(p => p == deletedProduct).ExecuteDelete();
            }
        }

        public async Task<List<Product>> GetAll()
        {
            return await _context.Products.ToListAsync();
        }
        public async Task<List<Product>> GetByBrend(Brend brend)
        {
            return await _context.Products.Where(p => p.Brend == brend).ToListAsync();
        }

        public async Task<List<Product>> GetByType(ProductType type)
        {
            return await _context.Products.Where(p => p.productType == type).ToListAsync();
        }

        public async Task<Product?> GetById(int id)
        {
            var result = await _context.Products.FirstOrDefaultAsync(p => p.Id == id);
            return result;
        }

        public async Task Update(int id, Product updatedProduct)
        {
            var oldProduct = await GetById(id);
            if (oldProduct is not null)
            {
                oldProduct.Name = updatedProduct.Name;
                oldProduct.Description = updatedProduct.Description;
                oldProduct.Price = updatedProduct.Price;
                oldProduct.Brend = updatedProduct.Brend;
                oldProduct.productType = updatedProduct.productType;
                await _context.SaveChangesAsync();
            }
        }
    }
}
