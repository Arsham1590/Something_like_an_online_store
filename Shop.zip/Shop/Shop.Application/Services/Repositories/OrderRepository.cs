﻿using Shop.Application.Services.Interfaces;
using Shop.Data.Data;
using Shop.Data.Models;
namespace Shop.Application.Services.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        public AppDbContext _context;

        public OrderRepository(AppDbContext appDbContext)
        {
            _context = appDbContext;
        }
        public async Task<string> MakeOrder(User user)
        {


            decimal sum=0;
            string message = "";
            foreach(var item in user.Cart)
            {
                message += item.Key.Name + "\n";
                sum += item.Key.Price * item.Value;
            }
            message += sum.ToString();

            var order = new Order(user,sum);
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();

            return message;
        }
    }
}
