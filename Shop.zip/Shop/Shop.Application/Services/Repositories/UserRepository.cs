﻿using Microsoft.EntityFrameworkCore;
using Shop.Application.Services.Interfaces;
using Shop.Data.Data;
using Shop.Data.Models;

namespace Shop.Application.Services.Repositories
{
    public class UserRepository : IUserRepository
    {
        public AppDbContext _context;
        private IQueryable<User> _users;
        private readonly IJwtTokenCreater _jwtCreater;
        private readonly IOrderRepository _orderRepository;
        private static User CurrentUser { get; set; } = null!;

        public static List<string> _admins = new()
        {
            "admin1@admin.com", "admin2@admin.com", "admin3@admin.com"
        };

        public UserRepository(AppDbContext _context, IJwtTokenCreater _jwtCreater,IOrderRepository _orderRepository)
        {
            this._jwtCreater = _jwtCreater;
            this._context = _context;
            this._orderRepository = _orderRepository;
            _users = _context.Users;
        }
        private bool FindMail(string mail)
        {
            return _context.Users.Select(u => u.Email).Contains(mail);
        }

        public async Task<string> GetUser(string mail, string password)
        {
            if (FindMail(mail))
            {
                var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == mail);
                if (PasswordHasher.Verify(password, user!.Password))
                {
                    CurrentUser = user;
                    CurrentUser.Cart = user.Cart;
                    var token = _jwtCreater.Generate(CurrentUser);
                    return token;
                }
            }
            throw new Exception();
        }

        public async Task Register(string name, string email, string password)
        {
            if (FindMail(email))
            {
                throw new Exception();
            }
            else
            {
                var hashedPassword = PasswordHasher.Generate(password);
                var user = new User(name, email, hashedPassword);

                user.isAdmin = _admins.Contains(email) ? true : false;

                await _context.Users.AddAsync(user);

                await _context.SaveChangesAsync();
            }
        }
        public async Task AddToCart(int productId)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == productId);
            if (product!=null)
            {
                if (CurrentUser!.Cart.ContainsKey(product!)) { CurrentUser.Cart[product!] += 1; }
                else { CurrentUser.Cart.Add(product!, 1); }
                await _context.SaveChangesAsync();
            }
            else { throw new Exception(); }
        }
        public async Task<string> MakePurchase()
        {
            return await _orderRepository.MakeOrder(CurrentUser!);
        }
        public async Task Delete(string mail)
        {
            if (FindMail(mail))
            {
                await _context.Users.Where(u=>u.Email==mail).ExecuteDeleteAsync();
                await _context.SaveChangesAsync();
            }
        }
    }
}
