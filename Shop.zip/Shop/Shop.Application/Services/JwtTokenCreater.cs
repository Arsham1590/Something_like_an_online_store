﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Shop.Data.Models;
using Microsoft.Extensions.Options;

namespace Shop.Application.Services
{
    public class JwtTokenCreater(IOptions<JwtOptions> _options):IJwtTokenCreater
    {
        public readonly JwtOptions _jwtOptions = _options.Value;
        public string Generate(User user)
        {
            Claim[] claims =
                [
                    new("Id", user.Id.ToString()),
                    new("isAdmin", user.isAdmin.ToString())
                ];

            var signingCredentials = new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtOptions.SecretKey)),
                SecurityAlgorithms.HmacSha256
                );

            var token = new JwtSecurityToken(
                claims: claims,
                signingCredentials: signingCredentials,
                expires: DateTime.UtcNow.AddHours(_jwtOptions.ExpiresHours)
                );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
            return tokenString;
        }

    }
}
