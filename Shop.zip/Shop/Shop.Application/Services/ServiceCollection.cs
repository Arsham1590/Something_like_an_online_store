﻿using Microsoft.Extensions.DependencyInjection;
using Shop.Application.Services.Interfaces;
using Shop.Data.Data;
using Shop.Data.Models;
using Shop.Data;
using Microsoft.EntityFrameworkCore;
using Shop.Application.Services.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc.ActionConstraints;


namespace Shop.Application.Services
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddShopServices(this IServiceCollection services)
        {
            var connectionString = "Server=DESKTOP-JT7II6O;Database=YourDatabase;Trusted_Connection = True;TrustServerCertificate=True;";

            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseSqlServer(connectionString);
            });
            services.AddTransient<IProductRepository, ProductRepository>();
            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<IOrderRepository, OrderRepository>();

            services.AddScoped<IJwtTokenCreater,JwtTokenCreater>();
            services.AddScoped<PasswordHasher>();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
                {
                    options.TokenValidationParameters = new()
                    {
                        ValidateAudience = false,
                        ValidateIssuer = false,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes("SecretKey123SecretKey123SecretKey123SecretKey123SecretKey123SecretKey123SecretKey123SecretKey123"))
                    };

                    options.Events = new JwtBearerEvents
                    {
                        OnMessageReceived = context =>
                        {
                            context.Token = context.Request.Cookies["Cookie_name"];
                            return Task.CompletedTask;
                        }
                    };
                });
            services.AddAuthorization(options =>

                options.AddPolicy("AdminPolicy", policy =>
                {
                    policy.RequireClaim("isAdmin", "True");

                }));


            return services;
        }
    }
}
