﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shop.Application.Services.Interfaces;
using Shop.Data.Models;

namespace Shop.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [AllowAnonymous]
        [HttpGet("Login", Name = "GetUser")]
        public async Task<IActionResult> GetUser(string mail, string password)
        {
            var token = await _userRepository.GetUser(mail, password);
            HttpContext.Response.Cookies.Append("Cookie_name", token);
            return Ok(token);
        }

        [AllowAnonymous]
        [HttpPost("Create Account", Name = "Register")]
        public async Task<IActionResult> Register(string name, string email, string password)
        {
            await _userRepository.Register(name, email, password);
            return Ok();
        }

        [Authorize(Policy = "AdminPolicy")]
        [HttpDelete]
        public async Task<IActionResult> Delete(string mail)
        {
            await _userRepository.Delete(mail);
            return Ok();
        }

        [Authorize]
        [HttpPost("Make Purchase", Name = "MakePurchase")]
        public async Task<IActionResult> MakePurchase()
        {
            var message = await _userRepository.MakePurchase();
            return Ok(message);
        }
        [Authorize]
        [HttpPut("Add To Cart", Name ="AddToCart")]
        public async Task<IActionResult> AddToCart(int productid)
        {
            await _userRepository.AddToCart(productid);
            return Ok("Done");
        }
    }
}
