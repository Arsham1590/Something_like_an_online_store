﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shop.Application.Services.Interfaces;
using Shop.Data.Models;

namespace Shop.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpGet]
        public async Task<IEnumerable<Product>> Get()
        {
            return await _productRepository.GetAll();
        }

        [HttpGet("Id", Name = "GetById")]
        public async Task<Product?> GetById(int id)
        {
            return await _productRepository.GetById(id);
        }

        [HttpGet("Brend", Name = "GetByBrend")]
        public async Task<IEnumerable<Product>> GetByBrend(Brend brend)
        {
            return await _productRepository.GetByBrend(brend);
        }

        [HttpGet("ProductType", Name = "GetByType")]
        public async Task<IEnumerable<Product>> GetByType(ProductType productType)
        {
            return await _productRepository.GetByType(productType);
        }

        [Authorize(Policy = "AdminPolicy")]
        [HttpPost]
        public async Task<IActionResult> Post(string Name, string Description, decimal Price, Brend brend, ProductType type)
        {
            await _productRepository.Add(Name,Description,Price,brend,type);
            return Ok("Done");
        }

        [Authorize(Policy ="AdminPolicy")]
        [HttpPut]
        public async Task<IActionResult> Put(int id, Product product)
        {
            await _productRepository.Update(id, product);
            return Ok("Done");
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            await _productRepository.Delete(id);
            return Ok("Done");
        }
    }
}
